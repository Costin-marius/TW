import { useState } from "react";

export default function ComponentaTa() {
    const [ok, setOk] = useState(true);

    return (
        <div>
            {ok ? <p>Starea este ok</p> : <p>Starea nu este ok</p>}

            <button onClick={() => setOk(!ok)}>
                Schimba
            </button>
        </div>
    );
}