import React from "react";
import UserList from "./UserList";

function App() {
  return (
    <div>
      <h1>An app</h1>

      <h2>Students</h2>
      <UserList userType="student" />

      <h2>Teachers</h2>
      <UserList userType="teacher" />
    </div>
  );
}

export default App;
