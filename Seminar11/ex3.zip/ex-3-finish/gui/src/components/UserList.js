import { useEffect, useState } from "react";
import User from "./User";
import "./UserList.css";

const SERVER = "http://localhost:8080";

function UserList({ userType }) {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const getUsers = async () => {
      const response = await fetch(`${SERVER}/users`);
      const data = await response.json();
      setUsers(data.filter(u => u.type === userType));
    };
    getUsers();
  }, [userType]);

  return (
    <div className="user-list">
      {users.map(u => <User key={u.id} item={u} />)}
    </div>
  );
}

export default UserList;
