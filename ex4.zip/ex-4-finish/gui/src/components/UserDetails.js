import './UserDetails.css';

function UserDetails({ user }) {
  if (!user) return null; 

  return (
    <div className="user-details">
      <h3>Detalii utilizator</h3>
      <p>Username: {user.username}</p>
      <p>Full Name: {user.fullName}</p>
      <p>Type: {user.type}</p>
    </div>
  );
}

export default UserDetails;
